# app/models/course_session.py
from datetime import datetime
from app.extensions import db
from app.models.core import Student
from datetime import datetime
from app.extensions import db

class CourseSession(db.Model):
    __tablename__ = "course_sessions"

    id = db.Column(db.Integer, primary_key=True)

    # اتصال درست:
    course_id = db.Column(
        db.Integer,
        db.ForeignKey("courses.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    # قبلاً اشتباه: db.ForeignKey('user.id')
    mentor_id = db.Column(
        db.Integer,
        db.ForeignKey("mentors.id", ondelete="SET NULL"),
        nullable=True,
        index=True
    )

    topic = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    date = db.Column(db.DateTime, nullable=False, index=True)  # فرمت ورودی: YYYY-MM-DD HH:MM
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    course = db.relationship(
        "Course",
        backref=db.backref("sessions", lazy="dynamic", cascade="all, delete-orphan")
    )
    mentor = db.relationship("Mentor", backref=db.backref("sessions", lazy="dynamic"))

    def __repr__(self):
        return f"<CourseSession {self.topic} on {self.date}>"

class Attendance(db.Model):
    __tablename__ = 'attendance'

    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('course_sessions.id'), nullable=False)  # به جلسه مربوط است
    status = db.Column(db.String(50), nullable=False)  # وضعیت حضور (حضور، غیاب، دیر رسیدن)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)  # زمان ثبت حضور
    student_id = db.Column(
        db.Integer,
        db.ForeignKey(f"{Student.__tablename__}.id", ondelete="CASCADE"),
        nullable=False
    )
    session = db.relationship('CourseSession', backref='attendance')
    student = db.relationship('User', backref='attendance')

    def __repr__(self):
        return f"<Attendance for student {self.student_id} in session {self.session_id}>"
class SessionFile(db.Model):
    __tablename__ = 'session_files'

    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('course_sessions.id'), nullable=False)  # به جلسه مربوط است
    file_path = db.Column(db.String(255), nullable=False)  # مسیر فایل
    description = db.Column(db.String(255), nullable=True)  # توضیحات فایل
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)  # زمان آپلود فایل

    session = db.relationship('CourseSession', backref='session_files')

    def __repr__(self):
        return f"<SessionFile {self.file_path}>"