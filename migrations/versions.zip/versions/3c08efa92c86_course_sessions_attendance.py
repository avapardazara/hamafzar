"""course sessions + attendance

Revision ID: 3c08efa92c86
Revises: 120c3d63e9e5
Create Date: 2025-10-13 15:xx:xx.xxxxxx
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "3c08efa92c86"
down_revision = "120c3d63e9e5"
branch_labels = None
depends_on = None


def upgrade():
    # اگر اجرای قبلی نصفه مانده بود، جدول موقتی Alembic را پاک کن
    op.execute("DROP TABLE IF EXISTS _alembic_tmp_courses")

    # جدول جلسات دوره
    op.create_table(
        "course_sessions",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("course_id", sa.Integer, sa.ForeignKey("courses.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("session_date", sa.Date, nullable=False, index=True),
        sa.Column("start_time", sa.Time),
        sa.Column("end_time", sa.Time),
        sa.Column("room", sa.String(120)),
        sa.Column("note", sa.Text),
        sa.Column("created_at", sa.DateTime, nullable=False, server_default=sa.text("(CURRENT_TIMESTAMP)")),
    )
    op.create_index("ix_course_sessions_course_id", "course_sessions", ["course_id"])
    op.create_index("ix_course_sessions_session_date", "course_sessions", ["session_date"])

    # جدول حضور و غیاب
    op.create_table(
        "attendances",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("session_id", sa.Integer, sa.ForeignKey("course_sessions.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("student_id", sa.Integer, sa.ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("status", sa.String(12), nullable=False, server_default="PRESENT"),  # PRESENT | ABSENT | LATE
        sa.Column("note", sa.Text),
        sa.Column("created_at", sa.DateTime, nullable=False, server_default=sa.text("(CURRENT_TIMESTAMP)")),
        sa.UniqueConstraint("session_id", "student_id", name="uq_attend_session_student"),
    )
    op.create_index("ix_attendances_session_id", "attendances", ["session_id"])
    op.create_index("ix_attendances_student_id", "attendances", ["student_id"])


def downgrade():
    op.drop_index("ix_attendances_student_id", table_name="attendances")
    op.drop_index("ix_attendances_session_id", table_name="attendances")
    op.drop_table("attendances")

    op.drop_index("ix_course_sessions_session_date", table_name="course_sessions")
    op.drop_index("ix_course_sessions_course_id", table_name="course_sessions")
    op.drop_table("course_sessions")
